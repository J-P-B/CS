# Automation Task

**Note -** Please do not setup your own WebDriver implementation. This has already been done for you.

## Getting Started

**Opening this project**

This project is a Maven project, using Junit and using page object pattern for Selenium tests. There are a number of ways you can open this project, however the easiest way should be the following;

**Intellij Community Edition - [download](https://www.jetbrains.com/idea/download)**

*  Open Intellij
*  Click open project
*  Navigate to the POM.xml in the automation-task directory, select and click open
*  Click on Open as a project