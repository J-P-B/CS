package com.cybersmart.pages.automationtask;

import com.cybersmart.pages.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddAComputerPage extends BasePage {

    @FindBy(xpath = "//*[@id=\"main\"]/h1")
    private WebElement header;

    @FindBy(id= "name")
    private WebElement name;

    @FindBy(id = "introduced")
    private WebElement introduced;

    @FindBy(id = "discontinued")
    private WebElement discontinued;

    @FindBy(xpath = "//*[@id=\"company\"]")
    private WebElement company;

    @FindBy(xpath = "//*[@id=\"company\"]/option[2]")
    private WebElement appleInc;

    @FindBy(xpath = "//*[@id=\"main\"]/form/div/input")
    private WebElement createThisComputerButton;

    public AddAComputerPage(WebDriver driver) {
        super(driver);
    }
    public boolean isInitialized() throws InterruptedException {
        Thread.sleep(3000);
        return ( header.isDisplayed());
    }
    public void enterComputerName(String name) {
        this.name.clear();
        this.name.sendKeys(name);
    }

    public void enterIntroducedDate(String introducedDate) {
        this.introduced.clear();
        this.introduced.sendKeys(introducedDate);
    }

    public void enterDiscontinuedDate(String discontinuedDate) {
        this.discontinued.clear();
        this.discontinued.sendKeys(discontinuedDate);
    }

    public void selectAppleIncCompany() throws InterruptedException {
        company.click();
        Thread.sleep(2000);
        appleInc.click();
        Thread.sleep(2000);
    }

    public void clickCreateThisComputerButton(){ createThisComputerButton.click(); }
}