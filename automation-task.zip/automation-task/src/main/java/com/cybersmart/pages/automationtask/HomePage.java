package com.cybersmart.pages.automationtask;

import com.cybersmart.pages.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

    @FindBy(xpath = "//*[@id=\"main\"]/h1")
    private WebElement header;

    @FindBy(xpath = "//*[@id=\"main\"]/table/tbody/tr[1]/td[1]")
    private WebElement computerNameGridValue;

    @FindBy(xpath = "//*[@id=\"main\"]/table/tbody/tr[1]/td[2]")
    private WebElement introducedGridValue;

    @FindBy(xpath = "//*[@id=\"main\"]/table/tbody/tr[1]/td[3]")
    private WebElement discontinuedGridValue;

    @FindBy(xpath = "//*[@id=\"main\"]/table/tbody/tr[1]/td[4]")
    private WebElement companyGridValue;

    @FindBy(id = "add")
    private WebElement addANewComputerButton;

    public HomePage(WebDriver driver) {
        super(driver);
    }
    public boolean isInitialized() throws InterruptedException {
        Thread.sleep(3000);
        return ( header.isDisplayed());
    }
    public void navigateToAddAComputerPage(){ addANewComputerButton.click(); }

    public String confirmationComputerNameGridValue(){ return computerNameGridValue.getText(); }
    public String confirmationIntroducedGridValue(){ return introducedGridValue.getText(); }
    public String confirmationDiscontinuedGridValue(){ return discontinuedGridValue.getText(); }
    public String confirmationCompanyGridValue(){ return companyGridValue.getText(); }
}