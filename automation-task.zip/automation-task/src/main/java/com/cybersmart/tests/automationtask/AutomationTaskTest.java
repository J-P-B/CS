package com.cybersmart.tests.automationtask;

import com.cybersmart.pages.automationtask.HomePage;
import com.cybersmart.pages.automationtask.AddAComputerPage;
import com.cybersmart.tests.BaseTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AutomationTaskTest extends BaseTest {

    @BeforeEach
    void navigateToURL() { open("http://computer-database.herokuapp.com/computers");}

    @Test
    void test1() throws InterruptedException {
        HomePage homePage = new HomePage(driver);
        assertTrue(homePage.isInitialized());
        homePage.navigateToAddAComputerPage();
        AddAComputerPage addAComputerPage = new AddAComputerPage(driver);
        addAComputerPage.enterComputerName("AAAAA");
        addAComputerPage.enterIntroducedDate("2020-01-01");
        addAComputerPage.enterDiscontinuedDate("2030-12-31");
        addAComputerPage.selectAppleIncCompany();
        addAComputerPage.clickCreateThisComputerButton();
        assertEquals("AAAAA", homePage.confirmationComputerNameGridValue());
        assertEquals("01 Jan 2020", homePage.confirmationIntroducedGridValue());
        assertEquals("31 Dec 2030", homePage.confirmationDiscontinuedGridValue());
        assertEquals("Apple Inc.", homePage.confirmationCompanyGridValue());
        screenShotService.takeScreenshot("_success");
    }
}